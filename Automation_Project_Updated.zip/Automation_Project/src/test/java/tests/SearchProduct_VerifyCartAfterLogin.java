package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.CheckoutPage;
import pages.HomePage;
import pages.LoginPage;
import pages.ProductsPage;

public class SearchProduct_VerifyCartAfterLogin extends TestBase{
	HomePage homeObject = new HomePage(driver);
    ProductsPage productsObject = new ProductsPage(driver);
    CheckoutPage orderObject = new CheckoutPage(driver);
    CartPage cartObject = new CartPage(driver);
    LoginPage loginObject = new LoginPage(driver);

    @Test
    public void testProductSearch() throws InterruptedException {
        String expectedTitle = "Automation Exercise";
        String actualTitle = driver.getTitle();
        Assert.assertTrue(actualTitle.contains(expectedTitle), "Home page is not loaded properly");

        homeObject.openProductsPage();
        WebElement productsHeader = driver.findElement(By.xpath("//h2[text()='All Products']"));
        Assert.assertTrue(productsHeader.isDisplayed(), "All Products page header is not visible");

        productsObject.searchForProduct("POLO");
        
        cartObject.addFirstProductToCart();
        homeObject.openCart();
        
        homeObject.OpenLoginPage();		
		Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());		
		loginObject.userCanLogin("khaled9102001@gmail.com", "123456789");

		Assert.assertEquals("Logout",loginObject.logoutBtn.getText());        	 
        homeObject.openCart();
        
        cartObject.verifyCartPageVisible();
        cartObject.verifyProductAddedToCart("POLO");
    }
}

package tests;


import java.awt.AWTException;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.ContactUsPageWtihRobotWay;
import pages.HomePage;

public class ContactUs_HappyScenario extends TestBase {
	HomePage homeObject = new HomePage(driver);
	ContactUsPageWtihRobotWay contactUsObject = new ContactUsPageWtihRobotWay(driver);
  @Test
  public void testContactUs_ValidData() throws InterruptedException, AWTException {
	  Thread.sleep(2000);
	  homeObject.openContactUsPage();
	  Assert.assertEquals("GET IN TOUCH", contactUsObject.getInMessage.getText());
	  
	  Thread.sleep(3000);
	  contactUsObject.userCanContactUs("Abdelrahman", "abdelrahman@gmail.com", "Complain", "My order doesn't deliver yet");
	  
	  Thread.sleep(3000);
	  
	  Assert.assertEquals("Success! Your details have been submitted successfully.", contactUsObject.successMessage.getText());
  }
}

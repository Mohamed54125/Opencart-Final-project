package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.RegisterPage;

public class RegisterHappyScenario extends TestBase{
	HomePage homeObject = new HomePage(driver);
	RegisterPage registerObject = new RegisterPage(driver);
	
  @Test(priority = 1)
  public void Register_NewEmail_MandatoryAndOptional() throws InterruptedException {
	  Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color"));
	  homeObject.OpenRegisterationPage();
	  
	  Assert.assertEquals("New User Signup!", registerObject.newUserMessage.getText());	  
	  String name ="Khaled Wael";

	  registerObject.userCanRegister(name,"khaled9102002@gmail.com");
	  Assert.assertEquals("ENTER ACCOUNT INFORMATION", registerObject.enterAccountMessage.getText());
	  
	  registerObject.enterAccountInformation("123456789",22,"12","2002","Khaled","Wael","ITworx","Minia","Sayeda zeinab","United States","California","aaaaa","17611","0109810344");	  
	  String success = "Account Created!";
	  Assert.assertEquals(success.toUpperCase(), registerObject.successMessage.getText());
	  
	  registerObject.continueAccount();
	  
	  Assert.assertEquals("Logged in as "+name, registerObject.loggedInMessage.getText());
	  registerObject.deleteAccount();
	  Assert.assertTrue(registerObject.deleteMessage.getText().equalsIgnoreCase("Account Deleted!"));
	  registerObject.continueAccount();
  }
}

package tests;

import org.testng.annotations.Test;

import pages.Scroll_WithoutArrowPage;

public class Scroll_WithoutArrowBtn extends TestBase {

    Scroll_WithoutArrowPage scrollObject = new Scroll_WithoutArrowPage(driver);

    @Test
    public void verifyScrollWithoutArrowFunctionality() throws InterruptedException {
        scrollObject.scrollDownToBottom();
        scrollObject.scrollUpToTop();
    }
}

package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;

public class RemoveFromCart_Test extends TestBase {

    HomePage homeObject = new HomePage(driver);
    CartPage CartObject = new CartPage(driver);

    @Test
    public void removeProductFromCartTest() throws InterruptedException {
        
    	String expectedTitle = "Automation Exercise";
        String actualTitle = driver.getTitle();
        Assert.assertTrue(actualTitle.contains(expectedTitle), "Home page is not loaded properly");

        homeObject.openProductsPage();
        WebElement productsHeader = driver.findElement(By.xpath("//h2[text()='All Products']"));
        Assert.assertTrue(productsHeader.isDisplayed(), "All Products page header is not visible");

        CartObject.addFirstProductToCart();

        homeObject.openCart();
        CartObject.removeProductFromCart();

        CartObject.verifyProductRemoved();
    }
}

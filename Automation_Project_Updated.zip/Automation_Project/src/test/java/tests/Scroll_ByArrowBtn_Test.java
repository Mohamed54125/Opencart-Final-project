package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.Scroll_WithArrowPage;

import org.testng.annotations.Test;

public class Scroll_ByArrowBtn_Test extends TestBase{
  
  Scroll_WithArrowPage scrollObject = new Scroll_WithArrowPage(driver);

  @Test
  public void verifyScrollFunctionalityByArrow() throws InterruptedException {
	  
	  String expectedTitle = "Automation Exercise";
      String actualTitle = driver.getTitle();
      Assert.assertTrue(actualTitle.contains(expectedTitle), "Home page title is incorrect");
    
      scrollObject.scrollDownToSubscription();
      scrollObject.scrollUpToTop();
  }
}

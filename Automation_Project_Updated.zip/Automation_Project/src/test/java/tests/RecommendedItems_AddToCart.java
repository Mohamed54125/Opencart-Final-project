package tests;

import org.testng.Assert;
import org.testng.annotations.Test;

import pages.RecommendedItemsPage;

public class RecommendedItems_AddToCart extends TestBase{
	
  RecommendedItemsPage recommendedObject = new RecommendedItemsPage(driver);

  @Test
  public void addRecommendedProductToCart() throws InterruptedException {
	  
	  String expectedTitle = "Automation Exercise";
      String actualTitle = driver.getTitle();
      Assert.assertTrue(actualTitle.contains(expectedTitle), "Home page title is incorrect");
	  
      recommendedObject.scrollToRecommendedItems();
      recommendedObject.addFirstRecommendedProductToCart();
      recommendedObject.openCart();
      recommendedObject.verifyProductInCart();
  }
}

package tests;

import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.ProductDetailPage;

public class ViewProductQuantityInCart_Test extends TestBase {

    HomePage homeObject = new HomePage(driver);
    ProductDetailPage productDetailObject = new ProductDetailPage(driver);
    CartPage cartObject = new CartPage(driver);

    @Test
    public void verifyProductQuantityInCart() throws InterruptedException {
    
        productDetailObject.selectFirstProduct();

        productDetailObject.setProductQuantity(4);

        productDetailObject.addToCart();
        Thread.sleep(3000);

        productDetailObject.openCartAfterAddition();

        cartObject.verifyProductQuantity(4);
    }
}
package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.HomePage;
import pages.ProductDetailPage;
import pages.ProductsPage;

public class ProductDetailPage_Test extends TestBase {

    ProductDetailPage productDetailObject = new ProductDetailPage(driver);
    ProductsPage productsObject = new ProductsPage(driver);
    HomePage homeObject = new HomePage(driver);
    

    @Test
    public void productDetailsTest() throws InterruptedException {
        String expectedTitle = "Automation Exercise";
        String actualTitle = driver.getTitle();
        Assert.assertTrue(actualTitle.contains(expectedTitle), "Home page title is incorrect");
        
        homeObject.openProductsPage();
        WebElement productsHeader = driver.findElement(By.xpath("//h2[text()='All Products']"));
        Assert.assertTrue(productsHeader.isDisplayed(), "All Products page header is not visible");


        productsObject.navigateToProductsDetailPage();
        productDetailObject.selectFirstProduct();
        productDetailObject.verifyProductDetails();
    }
    
}


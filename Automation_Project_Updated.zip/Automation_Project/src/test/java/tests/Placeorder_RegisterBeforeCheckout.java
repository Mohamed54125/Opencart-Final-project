package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.CheckoutPage;
import pages.HomePage;
import pages.RegisterPage;

public class Placeorder_RegisterBeforeCheckout extends TestBase{
	HomePage homeObject = new HomePage(driver);
    RegisterPage registerObject = new RegisterPage(driver);
    CheckoutPage orderObject = new CheckoutPage(driver);
    CartPage cartObject = new CartPage(driver);

    @Test
    public void placeOrderBeforeCheckout() {
    	
    	Assert.assertEquals("rgba(255, 165, 0, 1)", homeObject.homeLink.getCssValue("color"));
   	    homeObject.OpenRegisterationPage();   	  
   	    Assert.assertEquals("New User Signup!", registerObject.newUserMessage.getText());	
    	
    	String name = "Khaled Wael";
        registerObject.userCanRegister(name, "khaled910@gmail.com");
        orderObject.registerDuringCheckout();
        registerObject.enterAccountInformation("123456789",22,"12","2002","Khaled","Wael","ITworx","Minia","Sayeda zeinab","United States","California","aaaaa","17611","0109810344");	  
        
        
        String success = "Account Created!";
  	    Assert.assertEquals(success.toUpperCase(), registerObject.successMessage.getText());   
  	    registerObject.continueAccount(); 
  	    Assert.assertEquals("Logged in as "+name, registerObject.loggedInMessage.getText());
  	    
        homeObject.openProductsPage();
        WebElement productsHeader = driver.findElement(By.xpath("//h2[text()='All Products']"));
        Assert.assertTrue(productsHeader.isDisplayed(), "All Products page header is not visible");

        cartObject.addFirstProductToCart();
        orderObject.proceedToCheckout();
        	 
        homeObject.openCart();
        orderObject.proceedToCheckout();
        orderObject.reviewOrderAndPlace("Please deliver my order quickly.");
        
        orderObject.enterPaymentDetails("khaled wael", "4111111111111111", "123", "12", "2025");
        orderObject.verifyOrderSuccess();
        registerObject.deleteAccount();
    }
}


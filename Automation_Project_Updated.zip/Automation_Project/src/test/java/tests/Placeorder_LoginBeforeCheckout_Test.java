package tests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.testng.Assert;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.CheckoutPage;
import pages.HomePage;
import pages.LoginPage;
import pages.RegisterPage;

public class Placeorder_LoginBeforeCheckout_Test extends TestBase{
	HomePage homeObject = new HomePage(driver);
	LoginPage loginObject = new LoginPage(driver);
    RegisterPage registerObject = new RegisterPage(driver);
    CheckoutPage orderObject = new CheckoutPage(driver);
    CartPage cartObject = new CartPage(driver);

    @Test
    public void placeOrderBeforeCheckout() {
    	
        homeObject.OpenLoginPage();
		
		Assert.assertEquals("Login to your account", loginObject.loginMessage.getText());
		
		loginObject.userCanLogin("khaled9102001@gmail.com", "123456789");

		Assert.assertEquals("Logout",loginObject.logoutBtn.getText());
  	    
        homeObject.openProductsPage();
        WebElement productsHeader = driver.findElement(By.xpath("//h2[text()='All Products']"));
        Assert.assertTrue(productsHeader.isDisplayed(), "All Products page header is not visible");

        cartObject.addFirstProductToCart();
        orderObject.proceedToCheckout();
        	 
        homeObject.openCart();
        orderObject.proceedToCheckout();
        orderObject.reviewOrderAndPlace("Please deliver my order quickly.");
        
        orderObject.enterPaymentDetails("khaled wael", "4111111111111111", "123", "12", "2025");
        orderObject.verifyOrderSuccess();
        registerObject.deleteAccount();
    }
}




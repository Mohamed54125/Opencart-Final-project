package tests;

import org.testng.annotations.Test;

import pages.CheckoutPage;

public class VerifyAddressInCheckout_Test extends TestBase{
	
	 CheckoutPage orderObject = new CheckoutPage(driver);
	
  @Test
  public void verifyDeliveryAndBillingAddress() {
      String registeredAddress = "Azizstreet\n123 Main Street\nNew York, NY 10001";

      orderObject.verifyAddresses(registeredAddress);
  }
}


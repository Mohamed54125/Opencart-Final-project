package tests;

import org.testng.annotations.Test;

import org.testng.annotations.BeforeTest;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import pages.HomePage;
import pages.ProductsPage;

import org.testng.annotations.Test;
import org.testng.Assert;

public class SearchProduct_Test extends TestBase {
	
	HomePage homeObject = new HomePage(driver);
    ProductsPage productsObject = new ProductsPage(driver);

    @Test
    public void testProductSearch() throws InterruptedException {
        String expectedTitle = "Automation Exercise";
        String actualTitle = driver.getTitle();
        Assert.assertTrue(actualTitle.contains(expectedTitle), "Home page is not loaded properly");

        homeObject.openProductsPage();
        WebElement productsHeader = driver.findElement(By.xpath("//h2[text()='All Products']"));
        Assert.assertTrue(productsHeader.isDisplayed(), "All Products page header is not visible");

        productsObject.searchForProduct("POLO");
        driver.navigate().refresh();
        
        driver.navigate().back();

        productsObject.searchForProduct("JEANS");
    }
}
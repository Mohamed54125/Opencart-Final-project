package tests;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import pages.CartPage;
import pages.HomePage;
import pages.PageBase;

public class AddToCart_Test extends TestBase {

    CartPage cartObject = new CartPage(driver);
    HomePage homeObject = new HomePage(driver);

    @Test
    public void addToCartTest() {
        homeObject.openProductsPage();
        cartObject.addFirstProductToCart();
        cartObject.addSecondProductToCart();
        cartObject.verifyCartItems();
    }
}
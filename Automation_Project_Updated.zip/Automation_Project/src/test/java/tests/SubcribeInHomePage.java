package tests;

import org.testng.annotations.Test;

import pages.HomePage;

public class SubcribeInHomePage extends TestBase{
  HomePage homeObject = new HomePage(driver);

  @Test
  public void verifySubscriptionFeature() throws InterruptedException {
      homeObject.verifySubscription("testuser@example.com");
  }
}

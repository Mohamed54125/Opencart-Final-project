package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import org.testng.annotations.Test;

public class Scroll_WithoutArrowPage extends PageBase{
	
	 public Scroll_WithoutArrowPage(WebDriver driver) {
		super(driver);
		
	}

	    @FindBy(xpath = "//h2[contains(text(),'SUBSCRIPTION')]")
	    WebElement subscriptionSection;

	    @FindBy(xpath = "//h1[contains(text(),'Full-Fledged practice website for Automation Engineers')]")
	    WebElement topText;

	    public void scrollDownToBottom() {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        js.executeScript("window.scrollTo(0, document.body.scrollHeight);");
	        Assert.assertTrue(subscriptionSection.isDisplayed(), "Subscription section is not visible.");
	    }

	    public void scrollUpToTop() {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        js.executeScript("window.scrollTo(0, 0);");
	        Assert.assertTrue(topText.isDisplayed(), "Top section text is not visible after scrolling up.");
	    }
}

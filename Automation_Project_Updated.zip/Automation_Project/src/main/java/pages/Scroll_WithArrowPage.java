package pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

public class Scroll_WithArrowPage extends PageBase {

    public Scroll_WithArrowPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(xpath = "//*[@id=\"footer\"]/div[1]/div")
    WebElement subscriptionSection;

    @FindBy(xpath = "//*[@id=\"scrollUp\"]")
    WebElement scrollUpArrow;
    
    @FindBy(xpath = "//*[@id=\"slider-carousel\"]/div")
    WebElement topText;

    public void scrollDownToSubscription() {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", subscriptionSection);
        Assert.assertTrue(subscriptionSection.isDisplayed(), "Subscription section is not visible.");
    }

    public void scrollUpToTop() throws InterruptedException {
        scrollUpArrow.click();
        Thread.sleep(3000);
        Assert.assertTrue(topText.isDisplayed(), "Top section text is not visible after scrolling up.");
    }
}
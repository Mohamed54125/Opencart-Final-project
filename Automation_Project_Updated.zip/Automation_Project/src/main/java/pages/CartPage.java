package pages;

import org.openqa.selenium.WebDriver;

import java.util.List;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
public class CartPage extends PageBase {

    public CartPage(WebDriver driver) {
    	super(driver);
	}

	@FindBy(xpath = "//a[@href='/products']")
    WebElement productsBtn;

    @FindBy(xpath = "//h2[text()='All Products']")
    WebElement productsHeader;

    @FindBy(css = ".features_items .product-image-wrapper")
    List<WebElement> products;

    @FindBy(xpath = "/html/body/section[2]/div/div/div[2]/div/div[2]/div/div[1]/div[2]/div/a")
    WebElement addToCartBtn;

    @FindBy(xpath = "//button[contains(text(),'Continue Shopping')]")
    WebElement continueShoppingBtn;
    
    @FindBy(xpath = "//a[@href='/view_cart']")
    WebElement viewCartBtn;

    @FindBy(xpath = "//td[@class='cart_price']")
    List<WebElement> productPrices;

    @FindBy(xpath = "//td[@class='cart_quantity']")
    List<WebElement> productQuantities;

    @FindBy(xpath = "//td[@class='cart_total']")
    List<WebElement> totalPrices;
    
    @FindBy(xpath = "//*[@id=\"product-1\"]/td[4]/button")
    WebElement productQuantity;  

    @FindBy(xpath = "//h2[contains(text(),'Shopping Cart')]")
    WebElement cartPageHeader;

    @FindBy(xpath = "//td[@class='cart_product']")
    List<WebElement> cartProducts;

    @FindBy(xpath = "//a[contains(@class, 'cart_quantity_delete')]")
    WebElement removeProductBtn;
    
    @FindBy(xpath = "//h2[contains(text(),'Shopping Cart')]")
    WebElement cartHeader;

    @FindBy(xpath = "//td[@class='cart_description']//a")
    List<WebElement> cartProductNames;

    
    
    public void addFirstProductToCart() {
        Actions action = new Actions(driver);
        action.moveToElement(products.get(0)).perform();
        addToCartBtn.click();
        continueShoppingBtn.click();
        }

        public void addSecondProductToCart() {
            Actions action = new Actions(driver);
            action.moveToElement(products.get(1)).perform();
            addToCartBtn.click();
            viewCartBtn.click();
        }

        public void verifyCartItems() {
            Assert.assertTrue(productPrices.size() == 2, "Both products are not added to the cart.");
            Assert.assertTrue(productQuantities.size() == 2, "Product quantities are incorrect.");
            Assert.assertTrue(totalPrices.size() == 2, "Total prices are incorrect.");
        }
        

        public void verifyProductQuantity(int expectedQuantity) {
            int actualQuantity = Integer.parseInt(productQuantity.getText());
            Assert.assertEquals(actualQuantity, expectedQuantity, "Incorrect product quantity in cart.");
        }
        

        public void verifyProductRemoved() {
            Assert.assertTrue(cartProducts.size() == 0, "Product was not removed successfully.");
        }

		public void removeProductFromCart() {
			Assert.assertTrue(cartProducts.size() > 0, "No products found in the cart.");
            removeProductBtn.click();
		}
		
		 public void verifyCartPageVisible() {
		        Assert.assertTrue(cartHeader.isDisplayed(), "Cart page is not displayed.");
		    }
		
		 public void verifyProductAddedToCart(String expectedProductName) {
		        boolean productFound = false;
		        
		        for (WebElement product : cartProductNames) {
		            if (product.getText().equalsIgnoreCase(expectedProductName)) {
		                productFound = true;
		                break;
		            }
		        }

		        Assert.assertTrue(productFound, "Product is not found in the cart.");
		    }
    }

package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;

public class CheckoutPage extends PageBase{
	
	public CheckoutPage(WebDriver driver) {
        super(driver);
    }	
	
	@FindBy(xpath = "//button[contains(text(),'Proceed To Checkout')]")
    WebElement proceedToCheckoutBtn;
	
	@FindBy(xpath = "//button[contains(text(),'Continue')]")
	WebElement continueBtn;

	@FindBy(xpath = "//a[contains(text(),'Logged in as')]")
	WebElement loggedInAsUser;

	@FindBy(xpath = "//textarea[@name='message']")
	WebElement orderCommentBox;
	
	@FindBy(xpath = "//button[contains(text(),'Place Order')]")
    WebElement placeOrderBtn;

    @FindBy(xpath = "//input[@name='name_on_card']")
    WebElement cardName;

    @FindBy(xpath = "//input[@name='card_number']")
    WebElement cardNumber;
    
    @FindBy(xpath = "//a[contains(text(),'Register / Login')]")
    WebElement registerLoginBtn;

    @FindBy(xpath = "//input[@name='cvc']")
    WebElement cardCVC;

    @FindBy(xpath = "//input[@name='expiry_month']")
    WebElement cardExpMonth;

    @FindBy(xpath = "//input[@name='expiry_year']")
    WebElement cardExpYear;

    @FindBy(xpath = "//button[contains(text(),'Pay and Confirm Order')]")
    WebElement payAndConfirmOrderBtn;
    
    @FindBy(xpath = "//h2[contains(text(),'Your order has been placed successfully!')]")
    WebElement orderSuccessMsg;
    
    @FindBy(xpath = "//a[contains(text(),'Delete Account')]")
    WebElement deleteAccountBtn;
    
    @FindBy(xpath = "//h2[contains(text(),'ACCOUNT DELETED!')]")
    WebElement accountDeletedMsg;
    
    @FindBy(xpath = "//h2[contains(text(),'Delivery Address')]")
    WebElement deliveryAddressHeader;

    @FindBy(xpath = "//h2[contains(text(),'Billing Address')]")
    WebElement billingAddressHeader;

    @FindBy(xpath = "//div[@class='delivery_address']")
    WebElement deliveryAddressDetails;

    @FindBy(xpath = "//div[@class='billing_address']")
    WebElement billingAddressDetails;
	
	public void proceedToCheckout() {
        proceedToCheckoutBtn.click();
    }


    public void registerDuringCheckout() {
        registerLoginBtn.click();
    }
    
    public void enterPaymentDetails(String name, String number, String cvc, String expMonth, String expYear) {
        cardName.sendKeys(name);
        cardNumber.sendKeys(number);
        cardCVC.sendKeys(cvc);
        cardExpMonth.sendKeys(expMonth);
        cardExpYear.sendKeys(expYear);
        payAndConfirmOrderBtn.click();
    }

    public void verifyOrderSuccess() {
        Assert.assertTrue(orderSuccessMsg.isDisplayed(), "Order placement failed.");
    }
    
    public void deleteAccount() {
        deleteAccountBtn.click();
        Assert.assertTrue(accountDeletedMsg.isDisplayed(), "Account deletion failed.");
        continueBtn.click();
    }

	public void reviewOrderAndPlace(String comment) {
		orderCommentBox.sendKeys(comment);
        placeOrderBtn.click();
		
	}
	


	public void verifyAddresses(String expectedAddress) {
		
		String actualDeliveryAddress = deliveryAddressDetails.getText();
	    String actualBillingAddress = billingAddressDetails.getText();

	    Assert.assertEquals(actualDeliveryAddress, expectedAddress, "Delivery address does not match registered address.");
	    Assert.assertEquals(actualBillingAddress, expectedAddress, "Billing address does not match registered address.");
	 }

}

package pages;

import java.time.Duration;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;

public class HomePage extends PageBase {
	
	public HomePage(WebDriver driver) {
		super(driver);
	}

	@FindBy(linkText = "Signup / Login")
	WebElement signUpLoginBtn;
	
	@FindBy(linkText = "Home")
	public WebElement homeLink;
	
	@FindBy(linkText = "Contact us")
	WebElement contactUsBtn;
	
	@FindBy(xpath = "//*[@id='header']/div/div/div/div[2]/div/ul/li[2]/a")
    WebElement productsBtn;

	@FindBy(xpath = "//*[@id=\"footer\"]/div[1]/div/div/div[2]/div/h2")
    WebElement subscriptionHeader;

    @FindBy(id = "susbscribe_email")
    WebElement emailInput;

    @FindBy(id = "subscribe")
    WebElement subscribeBtn;

    @FindBy(xpath = "//*[@id=\"success-subscribe\"]/div")
    public WebElement subscribeSuccessMessage; 

	@FindBy(xpath = "//a[@href='/view_cart']")
    WebElement viewCartBtn;

   
	
	public void OpenRegisterationPage() {
		signUpLoginBtn.click();
	}
	
	public void OpenLoginPage() {
		signUpLoginBtn.click();
	}
	
	public void openContactUsPage() {
		contactUsBtn.click();
	}

	public void openProductsPage() {
		productsBtn.click();
		
	}
	
	public void verifySubscription(String email) throws InterruptedException {
        
        JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", subscriptionHeader);

        Assert.assertTrue(subscriptionHeader.isDisplayed(), "Subscription section is not visible");

        emailInput.sendKeys(email);
        Thread.sleep(3000);
        
        subscribeBtn.click();

        Assert.assertTrue(subscribeSuccessMessage.isDisplayed(), "Subscription success message is not visible");
    }
	
	public void openCart() {
        viewCartBtn.click();
    }

}

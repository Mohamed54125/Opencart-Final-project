package pages;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.testng.Assert;
import java.util.List;

public class ProductDetailPage extends PageBase {

    public ProductDetailPage(WebDriver driver) {
        super(driver);
    }

    @FindBy(xpath = "//a[@href='/products']")
    WebElement productsBtn;

    @FindBy(css = ".product-information")
    WebElement productsHeader;

    @FindBy(xpath = "//div[@class='features_items']")
    WebElement productList;

    @FindBy(css = ".features_items .product-image-wrapper")
    List<WebElement> products;

    @FindBy(xpath = ".//a[contains(text(),'View Product')]")
    WebElement firstViewProduct;
    
    @FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]")
    WebElement detailSection;

    @FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/h2")
    WebElement name;

    @FindBy(xpath = "//div[@class='product-information']/p[1]")
    WebElement category;

    @FindBy(xpath = "//div[@class='product-information']/span/span")
    WebElement price;

    @FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[2]")
    WebElement availability;

    @FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[3]")
    WebElement condition;

    @FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/p[4]")
    WebElement brand;
    
    @FindBy(xpath = "//input[@id='quantity']")
    WebElement quantityInput;

    @FindBy(xpath = "/html/body/section/div/div/div[2]/div[2]/div[2]/div/span/button")
    WebElement addToCartBtn;
    
    @FindBy(xpath = "//*[@id=\"cartModal\"]/div/div/div[2]/p[2]/a/u")
    WebElement viewCartAfterAdd;
    
    @FindBy(xpath = "//h2[contains(text(),'Write Your Review')]")
    WebElement writeReviewHeader;

    @FindBy(id = "name")
    WebElement reviewNameInput;

    @FindBy(id = "email")
    WebElement reviewEmailInput;

    @FindBy(id = "review")
    WebElement reviewTextArea;

    @FindBy(xpath = "//button[contains(text(),'Submit')]")
    WebElement submitReviewBtn;

    @FindBy(xpath = "//span[contains(text(),'Thank you for your review.')]")
    WebElement reviewSuccessMsg;
    
    public void selectFirstProduct() throws InterruptedException {
        Assert.assertTrue(productList.isDisplayed(), "Product list is not visible");
        Assert.assertTrue(products.size() > 0, "No products found on the page");
        Thread.sleep(2000);

        WebElement firstViewProduct = products.get(0).findElement(By.xpath(".//a[contains(text(),'View Product')]"));
        firstViewProduct.click();
        Thread.sleep(3000);
    }

    public void verifyProductDetails() {
    	Assert.assertTrue(productsHeader.isDisplayed(), "All Products page is not displayed");
        Assert.assertTrue(detailSection.isDisplayed(), "Product detail section is not displayed");

        Assert.assertTrue(name.isDisplayed(), "Product name is not visible");
        Assert.assertTrue(category.isDisplayed(), "Category is not visible");
        Assert.assertTrue(price.isDisplayed(), "Price is not visible");
        Assert.assertTrue(availability.isDisplayed(), "Availability is not visible");
        Assert.assertTrue(condition.isDisplayed(), "Condition is not visible");
        Assert.assertTrue(brand.isDisplayed(), "Brand is not visible");
    }
    
    public void setProductQuantity(int quantity) {
        quantityInput.clear();
        quantityInput.sendKeys(String.valueOf(quantity));
    }

    public void addToCart() {
        addToCartBtn.click();
    }
    
    public void openCartAfterAddition() {
        viewCartAfterAdd.click();
    }
    
    public void submitReview(String name, String email, String reviewText) {
        reviewNameInput.sendKeys(name);
        reviewEmailInput.sendKeys(email);
        reviewTextArea.sendKeys(reviewText);
        submitReviewBtn.click();
        Assert.assertTrue(reviewSuccessMsg.isDisplayed(), "Review submission failed.");
    }
}

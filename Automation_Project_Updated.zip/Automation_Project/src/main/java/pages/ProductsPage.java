package pages;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import java.util.List;
import org.testng.Assert;

public class ProductsPage extends PageBase {

    public ProductsPage(WebDriver driver) {
        super(driver);
        PageFactory.initElements(driver, this);
    }

    @FindBy(id = "search_product")
    WebElement searchTxt;

    @FindBy(xpath = "//*[@id='submit_search']")
    WebElement searchBtn;
    
    @FindBy(xpath = "//div[@class='productinfo text-center']/p")
    List<WebElement> productList;
    
    @FindBy(xpath = "//a[@href='/products']")
    WebElement productsBtn;


    public void searchForProduct(String productName) throws InterruptedException {
    	searchTxt.clear();
        searchTxt.sendKeys(productName);
        Thread.sleep(3000);
        searchBtn.click();;

        Assert.assertTrue(productList.size() > 0, "No searched products found");

        for (WebElement product : productList) {
            String foundProductName = product.getText().toLowerCase();
            Assert.assertTrue(foundProductName.contains(productName.toLowerCase()), "Product doesn't match search query: " + foundProductName);
        }
    }

	public void navigateToProductsDetailPage() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
        js.executeScript("arguments[0].scrollIntoView(true);", searchTxt);
		 productsBtn.click();
		
	}
}

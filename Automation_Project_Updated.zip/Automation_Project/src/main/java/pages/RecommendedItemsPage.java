package pages;


import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.JavascriptExecutor;
import org.testng.Assert;
import java.util.List;

public class RecommendedItemsPage extends PageBase{
	
	 public RecommendedItemsPage(WebDriver driver) {
		super(driver);
	}
	    @FindBy(xpath = "//h2[contains(text(),'RECOMMENDED ITEMS')]")
	    WebElement recommendedItemsHeader;

	    @FindBy(css = ".recommended_items .product-image-wrapper")
	    List<WebElement> recommendedProducts;

	    @FindBy(xpath = "//button[contains(text(),'Add to cart')]")
	    WebElement addToCartBtn;

	    @FindBy(xpath = "//a[@href='/view_cart']")
	    WebElement viewCartBtn;

	    public void scrollToRecommendedItems() {
	        JavascriptExecutor js = (JavascriptExecutor) driver;
	        js.executeScript("arguments[0].scrollIntoView(true);", recommendedItemsHeader);
	        Assert.assertTrue(recommendedItemsHeader.isDisplayed(), "Recommended Items section is not visible.");
	    }
	    
	    public void addFirstRecommendedProductToCart() {
	        Assert.assertTrue(recommendedProducts.size() > 0, "No recommended products found.");
	        recommendedProducts.get(0).click();
	        addToCartBtn.click();
	    }

	    public void openCart() {
	        viewCartBtn.click();
	    }

	    public void verifyProductInCart() {
	        Assert.assertTrue(viewCartBtn.isDisplayed(), "Product is not in the cart.");
	    }
	

}
